#!/usr/bin/python3

import sys, os
from desktoptheme import resetTitlebarColors

def printHelp():
	print("python3 resettitlebarcolor.py")

if __name__ == '__main__':
	resetTitlebarColors()
